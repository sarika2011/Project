function showBanner(){
	console.log("function called");
}